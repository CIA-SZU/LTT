This program mainly implements the MaOEA-IBP which was described in our paper:

An Indicator-based Many-Objective Evolutionary Algorithm with Boundary Protection


**************************************************************************************************************************************

The code was written in matlab and based on the PlatEMO. PlatEMO is an open source and 
free MATLAB-based platform for evolutionary multi-objective optimization. 
Users should dowmnload the PlatEMO at https://github.com/BIMK/PlatEMO
Then copy the MaOEA-IBP folder to the PlatEMO\Algorithms\.Users can run PlatEMO by invoking the main()function.
Then the test module can be seen on the GUI. Users only needs to select the MaOEA-IBP algorithm, 
MOP and operator from the dorp-dowm list,input the corresonding parameters value in the text boxs.
Press the run button to execute the algorithm.The real-time population will be displayed in the axis.

**************************************************************************************************************************************

Note that, this code can be used only for non-commercial purposes. 
We'd appreciate your acknowledgement if you use the code. 

For any problem concerning the code, please feel free to contact Ms. Tingting Luo (luotingting2017@email.szu.edu.cn).
