function Population= EnvironmentalSelection(Population,K)
   [FrontNo,MaxFNo] = NDSort(Population.objs,K);
  St = find(FrontNo<=MaxFNo);
   Population=Population(St);
   
   PopObj= Normalization(Population.objs);
    [N,~]=size(PopObj);
    P=0.3;
   Con= (sum(PopObj.^P,2)).^(1/P)-1;
  Con(SelectCornerSolutions(PopObj))=-inf; 
    for i = 1 : N
        temp=repmat(PopObj(i,:),N,1)-PopObj;
        Angle(i,:) = max(temp,[],2);
    end
    Angle(logical(eye(N))) = +inf;
    Remain = 1 : length(PopObj);
    while length(Remain) > K
        [AA,index] = min(Angle(Remain,Remain),[],2);
        [teda,x] = min(AA);
        y=index(x,1);
        if teda<0
            Remain(y) = [];
        else
            if Con(Remain(x)) > Con(Remain(y)) 
                      Remain(x) = [];
                  else
                     Remain(y) = [];
            end
        end
    end
    Population = Population(Remain);
end
