function MatingPool = MatingSelection(PopObj)
        PopObj= Normalization(PopObj);
      [N,~]=size(PopObj);
    for i = 1 : N
        temp=PopObj-repmat(PopObj(i,:),N,1);
        d(i,:) = max(temp,[],2);
    end
    d(logical(eye(N))) = +inf;
    d  = sort(d,2);
    dk = 1./(sum(d(:,2:ceil(end*0.1)),2)+1);
    for i = 1 : N
        p = randperm(N,2);
        if(all(PopObj(p(1),:)>=PopObj(p(2),:),2))
            index=p(2);
        else
            if (all(PopObj(p(1),:)<=PopObj(p(2),:),2))
                index=p(1);
            else
                 [~,b]=min(dk(p,:));
                 index=p(b);
            end
        end
         MatingPool(i) = index;
    end
end