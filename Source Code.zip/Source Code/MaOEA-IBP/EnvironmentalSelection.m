function Population= EnvironmentalSelection(Population,K)
   
  % normalization of the Population
   PopObj= Normalization(Population.objs);
    [N,~]=size(PopObj);
    P=0.3;
   %calculate the Euclidean distance between each individual and the curve/surface C
  Con= (sum(PopObj.^P,2)).^(1/P)-1;
  Con(SelectCornerSolutions(PopObj))=-inf; 
   % calculate the I?+(x, y) value of each two individuals 
    for i = 1 : N
        temp=repmat(PopObj(i,:),N,1)-PopObj;
        Angle(i,:) = max(temp,[],2);
    end
    Angle(logical(eye(N))) = +inf;
    Remain = 1 : length(PopObj);
    while length(Remain) > K
        %find a pair of the individuals with minimum I?+ value in population 
        [AA,index] = min(Angle(Remain,Remain),[],2);
        [teda,x] = min(AA);
        y=index(x,1);
        % eliminated the dominated individual from population
        if teda<0
            Remain(y) = [];
        else
            % utilize the boundary protection strategy to eliminate a individual
            if Con(Remain(x)) > Con(Remain(y)) 
                      Remain(x) = [];
                  else
                     Remain(y) = [];
            end
        end
    end
    Population = Population(Remain);
end
